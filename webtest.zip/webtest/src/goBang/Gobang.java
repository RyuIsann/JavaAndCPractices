package goBang;
import java.util.*;
import java.lang.*;

public class Gobang {
	public int length; 						//判断字符串的 长度
	public int num;							//计数
	public char chessbord[][];					//存棋盘
	public int score[][] = new int [15][15];		//存每个位置的得分
	public int chess_x,chess_y;		        //最终落子的坐标
	public int max[][][] = new int [8000][8][3];
	public int count = -1;
	public int IsOver = 0;
	/*-----五子棋存在的各种棋型------*/
	String KindOfBlack[] = {
			"11111","011110","0011100","001110",",011100","011110","11110","01111","0101110",
			"0110110","0111010","010110","011010","01110","11100","00111","01011","01101","10101",
			"10110","10011","11010","11001","10001","00011","11000","10100","10010","01010","01001",
			"01100","00101","00110","0110","1010","0101","1100","0011","1001"
	};		//黑棋
	
	String KindOfWhite[] = {
			"22222","022220","0022200","002220",",022200","022220","22220","02222","0202220",
			"0220220","0222020","020220","022020","02220","22200","00222","02022","02202","20202",
			"20220","20022","22020","22002","20002","00022","22000","20200","20020","02020","02002",
			"02200","00202","00220","0220","2020","0202","2200","0022","2002"
	};		//白棋
	/*--------五子棋棋型--------*/
	
	int ScoreOfKind[] = {
		100000,3000,3000,500,500,500,500,500,500,500,500,500,500,100,100,100,100,100,100,100,100,100,100,
		10,40,40,20,10,20,10,40,20,40,20,10,10,20,20,5
	};
		

	
	/*-------------初始-----------*/
	public Gobang(char chessbord[][]){
		this.chessbord=chessbord;
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				score[i][j]=0;
				if(chessbord[i+5][j+5]!='0') {
					if(IsInLine(i+5,j+5,"11111")>0)
						IsOver=1;
					if(IsInLine(i+5,j+5,"22222")>0)
						IsOver=2;
				}
				System.out.print(chessbord[i+5][j+5]+" ");
			}
			System.out.println();
			
		}
		
		System.out.println();
		/*for(int i=0;i<39;i++) {
			System.out.print(ScoreOfKind[i]+" ");
		}
		System.out.println();*/		
	}
	/*-------------初始-----------*/
	
	
	
	
	/*------------四个方向的字符匹配-----------*/
	public int IsInLine(int x,int y,String str) {
		num=0;
		String UseToJudge=null;
		char[] s1=new char[9];			//横
		char[] s2=new char[9];			//纵
		char[] s3=new char[9];			//左斜
		char[] s4=new char[9];			//右斜
		for(int i=0;i<9;i++) {
			s1[i]=chessbord[x][y-4+i];
			s2[i]=chessbord[x-4+i][y];
			s3[i]=chessbord[x-4+i][y-4+i];
			s4[i]=chessbord[x+4-i][y-4+i];
		}
		
		UseToJudge=String.valueOf(s1);		//将棋盘数组转为字符串
		if(UseToJudge.indexOf(str)!=-1) 	//匹配字串
			num++;
				
		UseToJudge=String.valueOf(s2);
		if(UseToJudge.indexOf(str)!=-1) 
			num++;

		UseToJudge=String.valueOf(s3);
		if(UseToJudge.indexOf(str)!=-1)
			num++;
			
		UseToJudge=String.valueOf(s4);
		if(UseToJudge.indexOf(str)!=-1) 
			num++;
			
		return num;
		
	}
	/*------------四个方向的字符匹配-----------*/
	
	
	
	
	
	/*-------------判断是否值得计算-----------*/
	
	public int Judge_Exit(int x,int y) {
		int judge_ex=0;
		for(int i=0;i<5;i++) {
			if(chessbord[x-2+i][y-2+i]=='1'||chessbord[x-2+i][y-2+i]=='2') judge_ex++;
			if(chessbord[x][y-2+i]=='1'||chessbord[x][y-2+i]=='2') judge_ex++;
			if(chessbord[x-2+i][y]=='1'||chessbord[x-2+i][y]=='2') judge_ex++;
			if(chessbord[x+2-i][y-2+i]=='1'||chessbord[x+2-i][y-2+i]=='2') judge_ex++; 
		}
		return judge_ex;
	}
	
	/*------------判断是否值得计算结束---------*/
	
	
	
	
		
	/*---------------判断死棋--------------*/
	public int JudgeDeath(int x,int y) {
		int n=0;
		for(int i=0;i<3;i++) {
			if(chessbord[x-3+i][y]!='0'&&chessbord[x-3+i][y]!='3'&&chessbord[x-3+i][y]==chessbord[x+1+i][y])
				n+=10;
			if(chessbord[x][y-3+i]!='0'&&chessbord[x][y-3+i]!='3'&&chessbord[x][y-3+i]==chessbord[x][y+1+i])
				n+=20;
			if(chessbord[x-3+i][y-3+i]!='0'&&chessbord[x-3+i][y-3+i]!='3'&&chessbord[x-3+i][y-3+i]==chessbord[x+1+i][y+1+i])
				n+=20;
			if(chessbord[x-3+i][y+3-i]!='0'&&chessbord[x-3+i][y+3-i]!='3'&&chessbord[x-3+i][y+3-i]==chessbord[x+1+i][y-1-i])
				n+=20;
		}
		
		for(int i=0;i<2;i++) {
			if(chessbord[x-2+i][y]!='0'&&chessbord[x-2+i][y]!='3'&&chessbord[x-2+i][y]==chessbord[x+1+i][y])
				n+=50;
			if(chessbord[x][y-2+i]!='0'&&chessbord[x][y-2+i]!='3'&&chessbord[x][y-2+i]==chessbord[x][y+1+i])
				n+=50;
			if(chessbord[x-2+i][y-2+i]!='0'&&chessbord[x-2+i][y-2+i]!='3'&&chessbord[x-2+i][y-2+i]==chessbord[x+1+i][y+1+i])
				n+=50;
			if(chessbord[x-2+i][y+2-i]!='0'&&chessbord[x-2+i][y+2-i]!='3'&&chessbord[x-2+i][y+2-i]==chessbord[x+1+i][y-1-i])
				n+=50;
		}
		
		for(int i=0;i<1;i++) {
			if(chessbord[x-1+i][y]!='0'&&chessbord[x-1+i][y]!='3'&&chessbord[x-1+i][y]==chessbord[x+1+i][y])
				n+=100;
			if(chessbord[x][y-1+i]!='0'&&chessbord[x][y-1+i]!='3'&&chessbord[x][y-1+i]==chessbord[x][y+1+i])
				n+=100;
			if(chessbord[x-1+i][y-1+i]!='0'&&chessbord[x-1+i][y-1+i]!='3'&&chessbord[x-1+i][y-1+i]==chessbord[x+1+i][y+1+i])
				n+=100;
			if(chessbord[x-1+i][y+1-i]!='0'&&chessbord[x-1+i][y+1-i]!='3'&&chessbord[x-1+i][y+1-i]==chessbord[x+1+i][y-1-i])
				n+=100;
		}
		
		return n;
	}
	/*--------------判断死棋结束------------*/
	
	
	
	
	
	/*-------------给每个位置打分------------*/
	public void ScoreBord() {
		for(int i=5;i<20;i++) {
			for(int j=5;j<20;j++) {
				
				if(chessbord[i][j]=='0'&&Judge_Exit(i,j)!=0) {//System.out.print(Judge_Exit(i,j));
					chessbord[i][j]='1';		//如果下黑棋
					for(int k=0;k<39;k++) {
						score[i-5][j-5]+=(ScoreOfKind[k])*(IsInLine(i,j,KindOfBlack[k]));
					}
					chessbord[i][j]='2';		//如果下白棋
					for(int k=0;k<39;k++){
						score[i-5][j-5]+=(ScoreOfKind[k])*(IsInLine(i,j,KindOfWhite[k]));
					}
					chessbord[i][j]='0';
					
					//System.out.println(JudgeDeath(i,j));
					score[i-5][j-5]-=JudgeDeath(i,j);					
				}
			}
		}		
	}
	/*-------------给每个位置打分-------------*/
	
	
	
	

	/*--------------找最大的八个评分-----------*/
	public void FindMax() {
		count++;
		int score_max[][]=new int[15][15];		//避免对原值的篡改
		
		for(int i=0;i<15;i++)					//初始化
			for(int j=0;j<15;j++)
				score_max[i][j]=score[i][j];
		
		for(int i=0;i<8000;i++)
			for(int j=0;j<8;j++)
				max[i][j][2]=0;
		
		for(int i=0;i<8;i++) {					//寻找八次最大值
			for(int j=0;j<15;j++) {
				for(int k=0;k<15;k++) {
					if(max[count][i][2]<score_max[j][k]) {
						max[count][i][0]=j;
						max[count][i][1]=k;
						max[count][i][2]=score_max[j][k];
					}
				}
			}
			score_max[max[count][i][0]][max[count][i][1]]=0;
		}
		
		//for(int i=0;i<8;i++)
			//System.out.println(max[count][i][0]+","+max[count][i][1]+","+max[count][i][2]);
		
	}
	
	
	/*--------------找最大评分结束------------*/
	
	
	
	
	
	
	/*----------------决策-----------------*/
	public void decide() {
		ScoreBord();
		FindMax();
		/*for(int i=0;i<8;i++)
			System.out.println(max[0][i][0]+","+max[0][i][1]+","+max[0][i][2]);
		
		System.out.println("score:");
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				System.out.print(score[i][j]+" ");
			}
			System.out.println();
		}*/
		
		
		int max_decide[] = {0,0};
		for(int i=0;i<8;i++) {
			//System.out.println(count);
			chessbord[max[0][i][0]+5][max[0][i][1]+5]='2';
			ScoreBord();
			FindMax();
			max[7991][i][2]=0;
			for(int j=0;j<8;j++) {
				chessbord[max[1+i*585][j][0]+5][max[1+i*585][j][1]+5]='1';
				ScoreBord();
				FindMax();
				
				max[7990][j][2]=0;
				for(int k=0;k<8;k++) {
					chessbord[max[2+j*73+i*585][k][0]+5][max[2+j*73+i*585][k][1]+5]='2';
					ScoreBord();
					FindMax();
					max[7992][k][2]=0;
					for(int w=0;w<8;w++) {
						chessbord[max[3+k*9+j*73+i*585][w][0]+5][max[3+k*9+j*73+i*585][w][1]+5]='1';
						ScoreBord();
						FindMax();
						if(max[7992][k][2]<max[4+w+k*9+j*73+i*583][0][2]) {
							max[7992][k][2]=max[4+w+k*9+j*73+i*583][0][2];
						}
							
						chessbord[max[3+k*9+j*73+i*585][w][0]+5][max[3+k*9+j*73+i*585][w][1]+5]='0';
					}
					
					if(max[7990][j][2]<max[7992][k][2]) {
						max[7990][j][2]=max[7992][k][2];
					}
						
					chessbord[max[2+j*73+i*585][k][0]+5][max[2+j*73+i*585][k][1]+5]='0';
				}
				
				if(max[7991][i][2]<max[7990][j][2]) {
					max[7991][i][2]=max[7990][j][2];
				}
				
				chessbord[max[1+i*585][j][0]+5][max[1+i*585][j][1]+5]='0';
			}
			
			if(max_decide[1]<max[7991][i][2]) {
				max_decide[1]=max[7991][i][2];
				max_decide[0]=i;
			}
			chessbord[max[0][i][0]+5][max[0][i][1]+5]='0';
			
		}
		
		System.out.println();
		for(int i=5;i<20;i++) {
			for(int j=5;j<20;j++) {
				System.out.print(chessbord[i][j]+" ");
			}
			System.out.println();
		}
		
		chess_x=max[0][max_decide[0]][0];
		chess_y=max[0][max_decide[0]][1];
		/*for(int i=0;i<8;i++) {
			System.out.println(max[0][i][0]+" "+max[0][i][1]+" "+max[0][i][2]);
		}*/
		
	}
	
	/*---------------决策结束----------------*/
	
	
	
	
	public void test() {
		
		/*-----------棋盘制作----------*/
		char[][] position = new char [25][25];
		for(int i=0;i<25;i++){
			for(int p=0;p<5;p++){
				position[p][i]='3';
			}
			for(int p=20;p<25;p++){
				position[p][i]='3';
			}
		}
		for(int i=5;i<20;i++){
			for(int p=0;p<5;p++){
				position[i][p]='3';
			}
			for(int k=20;k<25;k++){
				position[i][k]='3';
			}
		}
		for(int i=5;i<20;i++) {
			for(int j=5;j<20;j++) {
				position[i][j]='0';
			}
		}
		/*---------棋盘制作结束---------*/
		
		/*--------数据测试---------*/
		position[12][9]='1';
		position[10][11]='2';
		position[12][10]='1';
		position[13][11]='1';
		position[12][11]='2';
		position[12][14]='1';
		position[12][13]='2';
		position[11][13]='2';
		position[10][13]='2';
		position[11][11]='1';
		position[10][10]='1';
		
		/*--------数据测试-----------*/
		
		
		Gobang ty =new Gobang(position);
		
		if(ty.IsOver!=0) {
			System.out.println("\n"+ty.IsOver);
		}
		else {
			ty.decide();
			System.out.println("\n"+ty.chess_x+" , "+ty.chess_y);
		}

		
		/*------------决策------------*/
		
		/*-----------决策完毕----------*/
	}
}