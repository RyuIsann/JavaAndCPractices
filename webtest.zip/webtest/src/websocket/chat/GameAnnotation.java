package websocket.chat;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

import util.HTMLFilter;

import goBang.Gobang;

@ServerEndpoint(value = "/websocket/chat")
public class GameAnnotation {
	
    private static final Log log = LogFactory.getLog(GameAnnotation.class);
    private int guestNum = 0;
    
    private static final AtomicInteger connectionIds = new AtomicInteger(0);
    private static final Set<GameAnnotation> connections = new CopyOnWriteArraySet<>();
    private static final AtomicInteger turn = new AtomicInteger(0);
    
    private final String nickname;
    private final int number;
    private Session session;
    
    
    public GameAnnotation() {
    	guestNum = connectionIds.getAndIncrement();
    	System.out.println("plus 1"+connectionIds.get());
    	number = connectionIds.get();
        nickname = ""+(guestNum+2);
        System.out.println("Guest has joind:"+guestNum);
        
    }
    
    
    @OnOpen
    public void start(Session session) {
        this.session = session;
        connections.add(this);
        System.out.println("A client has joined." + guestNum);
        try {
        	this.session.getBasicRemote().sendText(nickname+"");
        } catch(Exception e) {}
        if(guestNum >= 2) {
        	try{
        		this.session.getBasicRemote().sendText("x");
        		System.out.println("0minus 1"+connectionIds.get());
        	} catch(Exception e) { }
        	try {
                this.session.close();
                System.out.println("close");
            } catch (IOException e1) { }
        	connections.remove(this);
        }
    }
    
    
    @OnClose
    public void end() {
    	guestNum = connectionIds.getAndDecrement();
        connections.remove(this);
        String message = String.format("%s %s",nickname, "has disconnected.");
        System.out.println(message);
    }
    
    
    @OnMessage
    public void incoming(String message) {
    	System.out.println(message);
    	if(guestNum < 2) {
    		if(message.charAt(0) == 'a') {
    			
    			/*-----------棋盘制作----------*/
    			char[][] position = new char [25][25];
    			for(int i=0;i<25;i++){
    				for(int p=0;p<5;p++){
    					position[p][i]='3';
    				}
    				for(int p=20;p<25;p++){
    					position[p][i]='3';
    				}
    			}
    			for(int i=5;i<20;i++){
    				for(int p=0;p<5;p++){
    					position[i][p]='3';
    				}
    				for(int k=20;k<25;k++){
    					position[i][k]='3';
    				}
    			}
    			for(int i=5;i<20;i++) {
    				for(int j=5;j<20;j++) {
    					position[i][j]='0';
    				}
    			}
    			
    			/*---------棋盘制作结束---------*/
    			for(int i=5;i<20;i++) {
    				for(int j=5;j<20;j++) {
    					position[i][j]=message.charAt((i-5)*15+j-5+1);
    				}
    			}
    			
    			Gobang ty =new Gobang(position);
    			
    			if(ty.IsOver!=0) {
    				System.out.println("\n"+ty.IsOver);
    			}
    			else {
    				ty.decide();
    				try {
        				System.out.println("1234");
        				this.session.getBasicRemote().sendText(ty.chess_x+"a"+ty.chess_y+"b");
        				System.out.println("4321");
        			}catch(Exception e) { }
    				System.out.println("\n"+ty.chess_x+" , "+ty.chess_y);
    			}
    		}
    		else {
    			System.out.println("turn"+turn.get()+"number" +number);
        		String filteredMessage = message;
            	broadcast(filteredMessage);
    		}
    	} 	
    }
    
    
    @OnError
    public void onError(Throwable t) throws Throwable {
        log.error("Chat Error: " + t.toString(), t);
    }
    
  /*------getBasicRemote是用来给前台发页面消息的------*/
    private static void broadcast(String msg) {
    	System.out.println("broadcast");
        for (GameAnnotation client : connections) {
        	System.out.println("we have guest "+client.guestNum);
            try {
                synchronized (client) {
                	System.out.println("connection"+connectionIds.get());
                	if(connectionIds.get() <= 1) {
                		client.session.getBasicRemote().sendText("9"); 
                		System.out.println(0);
                	}
                	else {
                		System.out.println("number"+client.guestNum);
                		client.session.getBasicRemote().sendText(msg); 
                		System.out.println(1);
                	}
                }
            } catch (IOException e) {
                log.debug("Chat Error: Failed to send message to client", e);
                connections.remove(client);
                try {
                    client.session.close();
                } catch (IOException e1) { }
                connectionIds.getAndDecrement();
                System.out.println("2minus 1"+connectionIds.get());
            }
        }
    }
}